var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["056e242a-f7b9-4074-b3f5-5a924f1e711d","b21ad990-1336-422c-9cdf-7d1b7cf1ec8a","e9e389e1-cb39-441d-bb35-a1497e3eac13","c1eda250-b83f-440b-9c27-7b266cf62510"],"propsByKey":{"056e242a-f7b9-4074-b3f5-5a924f1e711d":{"name":"watermelon","sourceUrl":"assets/api/v1/animation-library/gamelab/x7clt1ZttERzhwHg0q8dkZ5v_f11YkX6/category_food/watermelon.png","frameSize":{"x":620,"y":361},"frameCount":1,"looping":true,"frameDelay":2,"version":"x7clt1ZttERzhwHg0q8dkZ5v_f11YkX6","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":620,"y":361},"rootRelativePath":"assets/api/v1/animation-library/gamelab/x7clt1ZttERzhwHg0q8dkZ5v_f11YkX6/category_food/watermelon.png"},"b21ad990-1336-422c-9cdf-7d1b7cf1ec8a":{"name":"watermelon_1","sourceUrl":"assets/api/v1/animation-library/gamelab/x7clt1ZttERzhwHg0q8dkZ5v_f11YkX6/category_food/watermelon.png","frameSize":{"x":620,"y":361},"frameCount":1,"looping":true,"frameDelay":2,"version":"x7clt1ZttERzhwHg0q8dkZ5v_f11YkX6","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":620,"y":361},"rootRelativePath":"assets/api/v1/animation-library/gamelab/x7clt1ZttERzhwHg0q8dkZ5v_f11YkX6/category_food/watermelon.png"},"e9e389e1-cb39-441d-bb35-a1497e3eac13":{"name":"watermelon_2","sourceUrl":"assets/api/v1/animation-library/gamelab/x7clt1ZttERzhwHg0q8dkZ5v_f11YkX6/category_food/watermelon.png","frameSize":{"x":620,"y":361},"frameCount":1,"looping":true,"frameDelay":2,"version":"x7clt1ZttERzhwHg0q8dkZ5v_f11YkX6","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":620,"y":361},"rootRelativePath":"assets/api/v1/animation-library/gamelab/x7clt1ZttERzhwHg0q8dkZ5v_f11YkX6/category_food/watermelon.png"},"c1eda250-b83f-440b-9c27-7b266cf62510":{"name":"retrocreature","sourceUrl":"assets/api/v1/animation-library/gamelab/3OPR7fNp2GuC01rgoimtapzXeAYybc.O/category_retro/retrocreature_03.png","frameSize":{"x":398,"y":365},"frameCount":1,"looping":true,"frameDelay":2,"version":"3OPR7fNp2GuC01rgoimtapzXeAYybc.O","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":398,"y":365},"rootRelativePath":"assets/api/v1/animation-library/gamelab/3OPR7fNp2GuC01rgoimtapzXeAYybc.O/category_retro/retrocreature_03.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var watermelon=createSprite(67,51,150,150);
watermelon.setAnimation("watermelon");
watermelon.scale=0.15;

var watermelon1=createSprite(190,161,150,150);
watermelon1.setAnimation("watermelon_1");
watermelon1.scale=0.15;

var watermelon2=createSprite(315,118,150,150);
watermelon2.setAnimation("watermelon_2");
watermelon2.scale=0.15;

var glove=createSprite(190,325,90,90);
glove.setAnimation("retrocreature");
glove.scale=0.15;

var score=0;


function draw() {
 background("yellow");
  
  
 if(keyDown("LEFT_ARROW")) {
  glove.velocityX="-5";
 }
 if(keyDown("RIGHT_ARROW")) {
   glove.velocityX="5";
 }
 if(keyDown("space")){
   watermelon.velocityY=3.85;
   watermelon1.velocityY=3.85;
   watermelon2.velocityY=3.85;
   
 }
 //display score
  textSize(15);
  stroke("red");
  text("Score :"+score,330,20);
 
 
 
 createEdgeSprites();
 glove.bounce(leftEdge);
 glove.bounce(rightEdge);
 
 if(glove.isTouching(watermelon)){
   watermelon.x=67;
   watermelon.y=51;
   score=score+1;
 }
  if(glove.isTouching(watermelon1)){
    watermelon1.x=190;
    watermelon1.y=161;
  score=score+1;
  }
if(glove.isTouching(watermelon2)){
  watermelon2.x=312;
  watermelon2.y=123;
  score=score+1;
}

if(watermelon.isTouching(bottomEdge)){
  watermelon.destroy();
  text("Lost one",70,40);
  
}
if(watermelon1.isTouching(bottomEdge)){
    text("Lost One",182,40);
    watermelon1.destroy();
  }

if(watermelon2.isTouching(bottomEdge)){
    text("Lost One",294,40);
    watermelon2.destroy();
  }

drawSprites();
}


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
